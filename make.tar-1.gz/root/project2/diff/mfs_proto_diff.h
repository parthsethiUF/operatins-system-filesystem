78c78
< 
---
> int fs_getnode(void);
