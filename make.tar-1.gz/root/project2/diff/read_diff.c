329a330,363
> 
> /*===========================================================================*
>  *				do_getnode				     *
>  *===========================================================================*/
> int do_getnode(int fdd,int class,int gs)
> 
> {
>   struct filp *f;
>   register struct vnode *vp;
>   int r=OK;
>   scratch(fp).file.fd_nr = fdd;
>   f = get_filp(scratch(fp).file.fd_nr, VNODE_WRITE);
>   vp = f->filp_vno;
>   r = req_getnode(vp->v_fs_e, vp->v_inode_nr, size, gs);
>   unlock_filp(f);
>   return(r);
> }
> /*===========================================================================*
>  *				get_karo				     *
>  *===========================================================================*/
> int getkaro(struct filp *f,int size, int gs)
> {
>   register struct vnode *vp;
>     int r;
>     vp = f->filp_vno;
>        r = OK;
> 	r = req_getnode(vp->v_fs_e, vp->v_inode_nr, size, gs);
>         
>   return(r);
> }
> 
> /*===========================================================================*
>  *					      		                     *
>  *===========================================================================*/
