51a52
> #include <string.h>
114c115,136
< 
---
> 	if(strcmp(mode,"r") == 0)
> 	{
> 		if(get_tag(getpid())<get_class(fp))
> 			{
> 				return NULL;
> 			}
> 	}
> 	if( (strcmp(mode,"w") == 0) || (strcmp(mode,"a") == 0))
> 	{
> 		if(get_tag(getpid())>get_class(fp))
> 			{
> 				return NULL;
> 			}
> 	}
> 	if( (strcmp(mode,"w+") == 0) || (strcmp(mode,"a+") == 0) || (strcmp(mode,"r+") == 0))
> 	{
> 		if(get_tag(getpid()) != get_class(fp))
> 			{
> 				return NULL;
> 			}
> 	}
> 	
