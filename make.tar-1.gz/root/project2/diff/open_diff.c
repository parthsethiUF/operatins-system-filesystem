136c136,144
< 	if (r == OK)exist = FALSE;	/* We just created the file */
---
> 	if (r == OK) {
> 	exist = FALSE;
> 	  message m;
>           int p;
>           m.m1_i1 = fp->fp_pid;  // set first integer of message to PID
>           m.m1_i3 = 1;    //is used to differentiate between set tag and get tag, third integer is 1 for get_tag
>           p = _taskcall(PM_PROC_NR, 69, &m);  // invoke underlying system call
> 	  req_getnode(vp->v_fs_e, vp->v_inode_nr, p, 1);
> 	}	/* We just created the file */
