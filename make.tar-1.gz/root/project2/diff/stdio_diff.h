306a307,308
> int get_class(FILE *fp);
> int set_class(FILE *fp, int i);
