680c680,713
< }
\ No newline at end of file
---
> }
> 
> /*===========================================================================*
>  *				fs_getnode				     *
>  *===========================================================================*/
> int fs_getnode()
> {
>   int r;
>   register struct inode *rip;
>   int gs, pmclass;
>   r = OK;
>   int li;
>   if ((rip = find_inode(fs_dev, (ino_t) fs_m_in.REQ_INODE_NR)) == NULL)
> 	return(EINVAL);
>   gs = fs_m_in.REQ_PATH_SIZE;
>   pmclass = fs_m_in.REQ_COUNT;
>   if(gs == 1)//set class
> 	{
> 		 rip->i_zone[9] = pmclass;
> 		 li = rip->i_zone[9];
> 	}
>   if(gs == 2)//get class
> 	{
> 		li = rip->i_zone[9];
> 	}
> 
>    IN_MARKDIRTY(rip); 
>    fs_m_out.REQ_CLASS = li;
>    //--------------------------------------------------------------------
> 
>    rw_inode(rip,WRITING); 
>    //put_inode(rip);
>     return(OK);
> }
