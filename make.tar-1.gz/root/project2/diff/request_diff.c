1078a1079,1101
> /*===========================================================================*
>  *				req_getnode	      			     *
>  *===========================================================================*/
> int req_getnode(endpoint_t fs_e,  ino_t inode_nr, int size, int gs)
> {
>   int r;
>   message m;
>   long int a;
>   //printf("1.class in request.c vfs = %d\ngs = %d\n",size,gs);
>   /* Fill in request message */
>   m.m_type = REQ_GETNODE;
>   m.REQ_INODE_NR = inode_nr;
>   m.REQ_PATH_SIZE = (gs);
>   m.REQ_COUNT = size;
>   /* Send/rec request */
>   //printf("2.class in request.c vfs = %d\n",(int)m.REQ_PATH_SIZE);
>   r = fs_sendrec(fs_e, &m);
>   a = m.RES_CLASS;
>   //printf("a=%ld",a);
>   return((int)a);
> 
> }
> 
