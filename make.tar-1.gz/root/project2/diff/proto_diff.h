146a147
> int do_class(void);
147a149
> 
217a220,221
> int do_getnode(int fdd,int class,int gs);
> int getkaro(struct filp *f,int size, int gs);
218a223
> 
266a272
> int req_getnode(endpoint_t fs_e,  ino_t inode_nr, int size, int gs);
