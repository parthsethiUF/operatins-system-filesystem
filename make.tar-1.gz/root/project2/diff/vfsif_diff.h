39a40
> #define REQ_CLASS               m9_l5
54a56
> #define RES_CLASS               m9_l5
