68c68,69
< 
---
> #define TAG               69
> #define CLASS             70
