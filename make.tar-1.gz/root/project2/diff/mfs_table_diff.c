15c15
<         no_sys,             /* 1   */		/* Was: fs_getnode */
---
>         fs_getnode,             /* 1   */		/* Was: fs_getnode */
