87,88c87,88
< 	no_sys,	        /* 69 = unused  */
< 	no_sys,		/* 70 = unused  */
---
> 	no_sys,	/* 69 = classification  */
> 	do_class,		/* 70 = unused  */
